import React, { useEffect, useState } from 'react';
import { useWeb3React } from '@web3-react/core';
import Borrower from './Borrower';
import Lender from './Lender';
import { injected } from './Connectors';
import functions from './utils/functions';
import DetailsPage from './DetailsPage';

const Home = () => {
  const context = useWeb3React();
  const { account, activate } = context;

  const [selectedTab, setSelectedTab] = useState('home');
  const [pendingRequests, setPendingRequests] = useState([]);
  const [ongoingRequests, setOngoingRequests] = useState([]);
  const [allowance, setAllowance] = useState(null);
  const [detailsSelected, setDetailsSelected] = useState(null);
  const [fetchRequests, setFetchRequests] = useState(true);

  useEffect(() => {
    activate(injected);
    if (fetchRequests) {
      (async () => {
        try {
          const [pendingRequests, ongoingRequests] = await Promise.all([
            functions.getPendingRequests(),
            functions.getOngoingRequests(),
          ]);
          console.log('ongoign', ongoingRequests);
          setPendingRequests(pendingRequests);
          setOngoingRequests(ongoingRequests);
        } catch (error) {
          alert(`error while fetching requests ${error}`);
        }
      })();
      setFetchRequests(false);
    }
  }, [fetchRequests]);

  useEffect(() => {
    if (account) {
      (async () => {
        setAllowance(await functions.checkApproval(account));
      })();
    }
  }, [account]);

  const renderHeading = () => {
    if (selectedTab === 'home') {
      return (
        <h1 className="logo-heading">
          Block<span style={{ color: '#be0072' }}>chain</span> Based <br />{' '}
          Credit Report
          <span style={{ fontSize: 50, color: '#be0072' }}>.</span>
        </h1>
      );
    } else if (selectedTab === 'borrower') {
      return (
        <h1 className="logo-heading">
          Bor<span style={{ color: '#be0072' }}>ro</span>wer Section
          <span style={{ fontSize: 50, color: '#be0072' }}>.</span>
        </h1>
      );
    } else if (selectedTab === 'lender') {
      return (
        <h1 className="logo-heading">
          Le<span style={{ color: '#be0072' }}>nd</span>er Section
          <span style={{ fontSize: 50, color: '#be0072' }}>.</span>
        </h1>
      );
    } else if (selectedTab === 'details') {
      return (
        <h1 className="logo-heading">
          Bor<span style={{ color: '#be0072' }}>ro</span>wer History
          <span style={{ fontSize: 50, color: '#be0072' }}>.</span>
        </h1>
      );
    } else return null;
  };

  const renderSection = () => {
    if (selectedTab === 'home') {
      return (
        <div
          style={{
            display: 'flex',
            flexDirection: 'row',
          }}>
          <div className="account_info">
            <h3 className="account_info-title">Connected with this account:</h3>
            <p className="account_info-address">{context.account}</p>
          </div>
        </div>
      );
    } else if (selectedTab === 'lender') {
      return (
        <Lender
          pendingRequests={pendingRequests}
          ongoingRequests={ongoingRequests}
          allowance={allowance}
          setDetailsList={details => {
            console.log('these are details -', details);
            setDetailsSelected(details);
            setSelectedTab('details');
          }}
          setPendingRequests={setPendingRequests}
          setOngoingRequests={setOngoingRequests}
          setFetchRequests={setFetchRequests}
        />
      );
    } else if (selectedTab === 'borrower') {
      return (
        <Borrower
          pendingRequests={pendingRequests}
          ongoingRequests={ongoingRequests}
          allowance={allowance}
          setDetailsList={details => {
            setDetailsSelected(details);
            setSelectedTab('details');
          }}
          setOngoingRequests={setOngoingRequests}
          setFetchRequests={setFetchRequests}
        />
      );
    } else if (selectedTab === 'details') {
      return <DetailsPage details={detailsSelected} />;
    }
  };

  return (
    <div className="header">
      <div className="navbar">
        {renderHeading()}
        <button
          className="primary-btn"
          onClick={() => {
            setDetailsSelected(null);
            setSelectedTab('lender');
          }}>
          lender
        </button>
        <button
          style={{ marginLeft: 20 }}
          className="primary-btn"
          onClick={() => {
            setDetailsSelected(null);
            setSelectedTab('borrower');
          }}>
          borrower
        </button>
        {!parseFloat(allowance) ? (
          <button
            style={{ marginLeft: 20 }}
            className="primary-btn"
            onClick={() =>
              functions.giveApproval(context.account, setAllowance)
            }>
            Pay Approval
          </button>
        ) : null}
      </div>

      <div style={{ padding: '30px' }}>{renderSection()}</div>
    </div>
  );
};

export default Home;
