var Web3 = require('web3');
let axios = require('axios');
const BigNumber = require('bignumber.js');
let constants = require('./constants');

let web3 = new Web3(window.ethereum);

let contract = new web3.eth.Contract(constants.abi, constants.contract_address);
let erc20Contract = new web3.eth.Contract(
  constants.erc20abi,
  constants.erc20Address,
);

exports.convertWeiIntoEth = value => {
  return web3.utils.fromWei(value.toString());
};

exports.registerBorrower = async (accounts, cnic) => {
  await contract.methods
    .registerAsBorrower(cnic)
    .send({
      from: accounts,
      value: web3.utils.toWei(
        '0.02',
        'ether',
      ) /*** selected account from metamask ***/,
    }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', hash => {
      // hash of tx
    })
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
      }
    });
};

exports.removeBorrower = async accounts => {
  await contract.methods
    .removedAsBorrower()
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', hash => {
      // hash of tx
    })
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
      }
    });
};

exports.giveApproval = async (accounts, setAllowance) => {
  await erc20Contract.methods
    .approve(constants.contract_address, web3.utils.toWei('100000000'))
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', hash => {
      // hash of tx
    })
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
        setAllowance(1);
      }
    });
};

exports.checkApproval = async account => {
  console.log('account 0', account);
  return await erc20Contract.methods
    .allowance(account, constants.contract_address)
    .call(); // contract.methods.methodName(parameters).send({from:selected account})
};

exports.addRequest = async (
  amount,
  duration,
  accounts,
  confirmationCallback,
) => {
  duration = duration * 60;
  await contract.methods
    .requestFundsToBorrow(web3.utils.toWei(amount.toString()), duration)
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', hash => {
      // hash of tx
    })
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
        confirmationCallback();
      }
    });
};

exports.acceptRequest = async (
  accounts,
  id,
  pendingCb = () => {},
  confirmationCb = () => {},
) => {
  await contract.methods
    .AcceptRequest(id)
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', pendingCb)
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
        confirmationCb();
      }
    })
    .on('error', confirmationCb);
};

exports.ReportBorrower = async (
  accounts,
  id,
  pendingCb = () => {},
  confirmationCb = () => {},
) => {
  await contract.methods
    .ReportBorrower(id)
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', pendingCb)
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
        confirmationCb();
      }
    })
    .on('error', confirmationCb);
};

exports.payBackLoan = async (
  accounts,
  id,
  pendingCallback,
  confirmationCallback,
) => {
  await contract.methods
    .payBackLender(id)
    .send({ from: accounts /*** selected account from metamask ***/ }) // contract.methods.methodName(parameters).send({from:selected account})
    .on('transactionHash', pendingCallback)
    .on('confirmation', function (confirmationNumber, receipt) {
      if (confirmationNumber === 2) {
        // tx confirmed
        confirmationCallback();
      }
    })
    .on('error', confirmationCallback);
};

exports.getPendingRequests = async () => {
  let result = await axios({
    url: 'https://api.thegraph.com/subgraphs/name/fypbbcr/fyp-subgraph',
    method: 'post',
    data: {
      query: `
      {
            borrows(first: 1000,where:{status:"Pending"}) {
            id
            lender
            borrower
            amount
            status
            duration
            startingTime
        }
      }
      `,
    },
  });

  return result.data.data.borrows;
};

exports.getOngoingRequests = async () => {
  let result = await axios({
    url: 'https://api.thegraph.com/subgraphs/name/fypbbcr/fyp-subgraph',
    method: 'post',
    data: {
      query: `
      {
            borrows(first: 1000,where:{status:"ON Going"}) {
            id
            lender
            borrower
            amount
            status
            duration
            startingTime
        }
      }
      `,
    },
  });

  return result.data.data.borrows;
};

exports.getBorrowerDetails = async address => {
  let result = await axios({
    url: 'https://api.thegraph.com/subgraphs/name/fypbbcr/fyp-subgraph',
    method: 'post',
    data: {
      query: `
        {
          borrows(first: 1000,where:{borrower:"${address}"}){
                    id
                    lender
                    borrower
                    amount
                    status
                    startingTime
                    duration
                    CNIC
                    completionTime
          }
        }
      `,
    },
  });

  return result.data.data?.borrows;
};
