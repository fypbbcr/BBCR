import React from 'react';
import moment from 'moment';

let functions = require('./utils/functions');

const DetailsPage = props => {
  console.log('details in details page -', props.details);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignSelf: 'center',
          // width: '70vw',
          border: '1px solid #be0072',
          // padding: '20px',
        }}>
        <div
          className="info_row"
          style={{
            borderBottom: !props.details.length
              ? 'none'
              : '0.5px solid #be0072',
          }}>
          {/* <h3>Borrower</h3> */}
          <h3>Amount</h3>
          <h3>Duration</h3>
          <h3>Status</h3>
          <h3>CNIC</h3>
          <h3>Start Date</h3>
          <h3>Due Date</h3>
          <h3>Completion Date</h3>
        </div>
        {props.details
          .filter(request => request.status.toLowerCase() !== 'pending')
          .map((request, i) => {
            return (
              <div
                className="info_row"
                style={{
                  borderBottom:
                    i === props.details.length - 1
                      ? 'none'
                      : '0.5px solid #be0072',
                }}>
                {/* <p>
                  {request.borrower.slice(0, 8) +
                    '  ...........  ' +
                    request.borrower.slice(-8)}
                </p> */}
                <p>{functions.convertWeiIntoEth(request.amount)} DANI</p>
                <p>{parseFloat(request.duration) / 60} minutes</p>
                <p>{request.status}</p>
                <p>{request.CNIC}</p>
                <p
                  style={{
                    textAlign: request.startingTime ? 'left' : 'center',
                  }}>
                  {request.startingTime
                    ? moment(request.startingTime * 1000).format(
                        'DD-MM-YYYY h:mm a',
                      )
                    : '-'}
                </p>
                <p
                  style={{
                    textAlign: request.startingTime ? 'left' : 'center',
                  }}>
                  {request.startingTime
                    ? moment(
                        (parseFloat(request.startingTime) +
                          parseFloat(request.duration)) *
                          1000,
                      ).format('DD-MM-YYYY h:mm a')
                    : '-'}
                </p>
                <p
                  style={{
                    textAlign: request.completionTime ? 'left' : 'center',
                  }}>
                  {request.completionTime
                    ? moment(request.completionTime * 1000).format(
                        'DD-MM-YYYY h:mm a',
                      )
                    : '-'}
                </p>
              </div>
            );
          })}
      </div>
      {/* <input type="text" name="name" onChange={handleID3.bind(this)} />
        <button onClick={payBack}>Enter</button> */}
    </div>
  );
};

export default DetailsPage;
